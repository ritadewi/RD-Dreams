//
//  recordSoundViewController.swift
//  PitchPerfectWithSlider
//
//  Created by Rita Dewi on 15/10/2018.
//  Copyright © 2018 RitaDewi. All rights reserved.
//

import UIKit
import AVFoundation

class recordSoundViewController: UIViewController, AVAudioRecorderDelegate {

    var audioRecorder: AVAudioRecorder!
    
    @IBOutlet weak var recordingButton: UIButton!
    @IBOutlet weak var tapToRecord: UILabel!
    @IBOutlet weak var tapToStop: UILabel!
    @IBOutlet weak var buttonToStop: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        buttonToStop.isEnabled = false
        if !recordingButton.isOpaque {
            recordingButton.isEnabled = true
        }
    }
    
    @IBAction func recordButton(_ sender: Any) {
        tapToRecord.text = "Recording in progress"
        buttonToStop.isEnabled = true
        recordingButton.isEnabled = false
        
        let recordingFileName = "recordedVoice.wav"
        let recordingFilePath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let recordingFilePathString = recordingFilePath.absoluteString
        let pathArray1 = [recordingFilePathString, recordingFileName]
        let filePath = URL(string: pathArray1.joined(separator: "/"))
        
        let session = AVAudioSession.sharedInstance()
        
        try! session.setCategory(AVAudioSessionCategoryPlayAndRecord, with: AVAudioSessionCategoryOptions.defaultToSpeaker)
        try! audioRecorder = AVAudioRecorder(url: filePath!, settings: [:])
        
        audioRecorder.delegate = self
        audioRecorder.isMeteringEnabled = true
        audioRecorder.prepareToRecord()
        audioRecorder.record()
    }
    
    @IBAction func stopRecordingButton(_ sender: Any) {
        audioRecorder.stop()
        let audioSession = AVAudioSession.sharedInstance()
        try! audioSession.setActive(false)
    }
    
    func audioRecorderDidFinishRecording(_ recorder: AVAudioRecorder, successfully flag: Bool) {
        if flag {
            performSegue(withIdentifier: "playSegue", sender: audioRecorder.url)
        }
        else {
            print("Recording was not successful")
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "playSegue" {
            let playSoundViewController = segue.destination as! playSoundViewController
            let recordedAudioURL = sender as! URL
            playSoundViewController.recordedAudioURL = recordedAudioURL
        }
    }
    
}
